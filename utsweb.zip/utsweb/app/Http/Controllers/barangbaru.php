<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\barang;

class barangbaru extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $keyword = $request->keyword;
        $datas = barang::where('kode_barang', 'LIKE', '%'.$keyword.'%')
        ->orWhere('nama_barang', 'LIKE', '%'.$keyword.'%')
        ->orWhere('kategori_barang', 'LIKE', '%'.$keyword.'%')
        ->get();
        return view('indexGoods', compact('datas', 'keyword'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('createGoods');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'id' => 'required',
            'kode_barang' => 'required',
            'nama_barang' => 'required',
            'kategori_barang' => 'required',
            'harga' => 'required',
            'quantity' => 'required',
            ]);
            barang::create($request->all());
            return redirect('Barang');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $model = barang::find($id);
        return view('editGoods', compact('model'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $model = barang::find($id);
        $model->kode_barang = $request->kode_barang;
        $model->nama_barang = $request->nama_barang;
        $model->kategori_barang = $request->kategori_barang;
        $model->harga = $request->harga;
        $model->quantity = $request->quantity;
        $model->save();
        return redirect('Barang');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $model=barang::find($id);
        $model->delete();
        return redirect('Barang');
    }
}
