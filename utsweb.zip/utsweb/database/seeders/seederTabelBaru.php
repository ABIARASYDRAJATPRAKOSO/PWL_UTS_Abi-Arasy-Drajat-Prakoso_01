<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class seederTabelBaru extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('barangtabel')->insert([
            'id'=>'1',
            'kode_barang'=>'BRG001',
            'nama_barang'=>'Indomie',
            'kategori_barang'=>'Makanan',
            'harga'=>'3000',
            'quantity'=>'100',

        ]);

        DB::table('barangtabel')->insert([
            'id'=>'2',
            'kode_barang'=>'BRG002',
            'nama_barang'=>'Pocari Sweat',
            'kategori_barang'=>'Minuman',
            'harga'=>'6000',
            'quantity'=>'50',

        ]);

        DB::table('barangtabel')->insert([
            'id'=>'3',
            'kode_barang'=>'BRG003',
            'nama_barang'=>'Silver Queen',
            'kategori_barang'=>'Snack',
            'harga'=>'12500',
            'quantity'=>'45',

        ]);

        DB::table('barangtabel')->insert([
            'id'=>'4',
            'kode_barang'=>'BRG005',
            'nama_barang'=>'Garam Dapur',
            'kategori_barang'=>'Bumbu Dapur',
            'harga'=>'14500',
            'quantity'=>'75',

        ]);

        DB::table('barangtabel')->insert([
            'id'=>'5',
            'kode_barang'=>'BRG005',
            'nama_barang'=>'Lays',
            'kategori_barang'=>'Snack',
            'harga'=>'13500',
            'quantity'=>'85',

        ]);

        DB::table('barangtabel')->insert([
            'id'=>'6',
            'kode_barang'=>'BRG006',
            'nama_barang'=>'Kopi Kenangan',
            'kategori_barang'=>'Minuman',
            'harga'=>'9600',
            'quantity'=>'125',

        ]);

        DB::table('barangtabel')->insert([
            'id'=>'7',
            'kode_barang'=>'BRG007',
            'nama_barang'=>'Chitato',
            'kategori_barang'=>'Snack',
            'harga'=>'10500',
            'quantity'=>'90',

        ]);

        DB::table('barangtabel')->insert([
            'id'=>'8',
            'kode_barang'=>'BRG008',
            'nama_barang'=>'Super Bubur',
            'kategori_barang'=>'Makanan',
            'harga'=>'8700',
            'quantity'=>'45',

        ]);

        DB::table('barangtabel')->insert([
            'id'=>'9',
            'kode_barang'=>'BRG009',
            'nama_barang'=>'Bawang Putih Bubuk',
            'kategori_barang'=>'Bumbu Dapur',
            'harga'=>'9800',
            'quantity'=>'115',

        ]);

        DB::table('barangtabel')->insert([
            'id'=>'10',
            'kode_barang'=>'BRG010',
            'nama_barang'=>'Parsley Kering',
            'kategori_barang'=>'Bumbu Dapur',
            'harga'=>'17400',
            'quantity'=>'75',

        ]);
        
        DB::table('barangtabel')->insert([
            'id'=>'11',
            'kode_barang'=>'BRG011',
            'nama_barang'=>'Merica Bubuk',
            'kategori_barang'=>'Bumbu Dapur',
            'harga'=>'12700',
            'quantity'=>'79',

        ]);

        DB::table('barangtabel')->insert([
            'id'=>'12',
            'kode_barang'=>'BRG012',
            'nama_barang'=>'Kecap Asin',
            'kategori_barang'=>'Bumbu Dapur',
            'harga'=>'9700',
            'quantity'=>'90',

        ]);

        DB::table('barangtabel')->insert([
            'id'=>'13',
            'kode_barang'=>'BRG013',
            'nama_barang'=>'La Fonte Pasta',
            'kategori_barang'=>'Makanan',
            'harga'=>'18500',
            'quantity'=>'105',

        ]);

        DB::table('barangtabel')->insert([
            'id'=>'14',
            'kode_barang'=>'BRG014',
            'nama_barang'=>'Sarden Kaleng ABC',
            'kategori_barang'=>'Makanan',
            'harga'=>'15600',
            'quantity'=>'115',

        ]);

        DB::table('barangtabel')->insert([
            'id'=>'15',
            'kode_barang'=>'BRG015',
            'nama_barang'=>'Mie Oven',
            'kategori_barang'=>'Makanan',
            'harga'=>'8600',
            'quantity'=>'70',

        ]);

        DB::table('barangtabel')->insert([
            'id'=>'16',
            'kode_barang'=>'BRG016',
            'nama_barang'=>'NutriBoost',
            'kategori_barang'=>'Minuman',
            'harga'=>'9600',
            'quantity'=>'175',

        ]);

        DB::table('barangtabel')->insert([
            'id'=>'17',
            'kode_barang'=>'BRG017',
            'nama_barang'=>'Coca Cola',
            'kategori_barang'=>'Minuman',
            'harga'=>'10600',
            'quantity'=>'125',

        ]);

        DB::table('barangtabel')->insert([
            'id'=>'18',
            'kode_barang'=>'BRG018',
            'nama_barang'=>'Kinderjoy',
            'kategori_barang'=>'Snack',
            'harga'=>'11600',
            'quantity'=>'155',

        ]);

        DB::table('barangtabel')->insert([
            'id'=>'19',
            'kode_barang'=>'BRG019',
            'nama_barang'=>'Happy Tos',
            'kategori_barang'=>'Snack',
            'harga'=>'19600',
            'quantity'=>'145',

        ]);

        DB::table('barangtabel')->insert([
            'id'=>'20',
            'kode_barang'=>'BRG020',
            'nama_barang'=>'YOU C 100',
            'kategori_barang'=>'Minuman',
            'harga'=>'12600',
            'quantity'=>'135',

        ]);
    }
}
