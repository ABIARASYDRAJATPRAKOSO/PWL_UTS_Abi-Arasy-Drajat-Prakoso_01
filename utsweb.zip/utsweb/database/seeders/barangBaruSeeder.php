<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\barang;

class barangBaruSeeder extends Seeder
{
    /**
     * Run the database seeds.
     * 
     * @return void
     */
    public function run(): void
    {
        barang::create([
            'id'=>'2',
            'kode_barang'=>'BRG002',
            'nama_barang'=>'Pocari Sweat',
            'kategori_barang'=>'Minuman',
            'harga'=>'6000',
            'quantity'=>'50',

        ]);

        barang::create([
            'id'=>'3',
            'kode_barang'=>'BRG003',
            'nama_barang'=>'Silver Queen',
            'kategori_barang'=>'Snack',
            'harga'=>'12500',
            'quantity'=>'45',

        ]);

        barang::create([
            'id'=>'4',
            'kode_barang'=>'BRG005',
            'nama_barang'=>'Garam Dapur',
            'kategori_barang'=>'Bumbu Dapur',
            'harga'=>'14500',
            'quantity'=>'75',

        ]);

        barang::create([
            'id'=>'5',
            'kode_barang'=>'BRG005',
            'nama_barang'=>'Lays',
            'kategori_barang'=>'Snack',
            'harga'=>'13500',
            'quantity'=>'85',

        ]);

        barang::create([
            'id'=>'6',
            'kode_barang'=>'BRG006',
            'nama_barang'=>'Kopi Kenangan',
            'kategori_barang'=>'Minuman',
            'harga'=>'9600',
            'quantity'=>'125',

        ]);

        barang::create([
            'id'=>'7',
            'kode_barang'=>'BRG007',
            'nama_barang'=>'Chitato',
            'kategori_barang'=>'Snack',
            'harga'=>'10500',
            'quantity'=>'90',

        ]);

        barang::create([
            'id'=>'8',
            'kode_barang'=>'BRG008',
            'nama_barang'=>'Super Bubur',
            'kategori_barang'=>'Makanan',
            'harga'=>'8700',
            'quantity'=>'45',

        ]);

        barang::create([
            'id'=>'9',
            'kode_barang'=>'BRG009',
            'nama_barang'=>'Bawang Putih Bubuk',
            'kategori_barang'=>'Bumbu Dapur',
            'harga'=>'9800',
            'quantity'=>'115',

        ]);

        barang::create([
            'id'=>'10',
            'kode_barang'=>'BRG010',
            'nama_barang'=>'Parsley Kering',
            'kategori_barang'=>'Bumbu Dapur',
            'harga'=>'17400',
            'quantity'=>'75',

        ]);
        
        barang::create([
            'id'=>'11',
            'kode_barang'=>'BRG011',
            'nama_barang'=>'Merica Bubuk',
            'kategori_barang'=>'Bumbu Dapur',
            'harga'=>'12700',
            'quantity'=>'79',

        ]);

        barang::create([
            'id'=>'12',
            'kode_barang'=>'BRG012',
            'nama_barang'=>'Kecap Asin',
            'kategori_barang'=>'Bumbu Dapur',
            'harga'=>'9700',
            'quantity'=>'90',

        ]);

        barang::create([
            'id'=>'13',
            'kode_barang'=>'BRG013',
            'nama_barang'=>'La Fonte Pasta',
            'kategori_barang'=>'Makanan',
            'harga'=>'18500',
            'quantity'=>'105',

        ]);

        barang::create([
            'id'=>'14',
            'kode_barang'=>'BRG014',
            'nama_barang'=>'Sarden Kaleng ABC',
            'kategori_barang'=>'Makanan',
            'harga'=>'15600',
            'quantity'=>'115',

        ]);

        barang::create([
            'id'=>'15',
            'kode_barang'=>'BRG015',
            'nama_barang'=>'Mie Oven',
            'kategori_barang'=>'Makanan',
            'harga'=>'8600',
            'quantity'=>'70',

        ]);

        barang::create([
            'id'=>'16',
            'kode_barang'=>'BRG016',
            'nama_barang'=>'NutriBoost',
            'kategori_barang'=>'Minuman',
            'harga'=>'9600',
            'quantity'=>'175',

        ]);

        barang::create([
            'id'=>'17',
            'kode_barang'=>'BRG017',
            'nama_barang'=>'Coca Cola',
            'kategori_barang'=>'Minuman',
            'harga'=>'10600',
            'quantity'=>'125',

        ]);

        barang::create([
            'id'=>'18',
            'kode_barang'=>'BRG018',
            'nama_barang'=>'Kinderjoy',
            'kategori_barang'=>'Snack',
            'harga'=>'11600',
            'quantity'=>'155',

        ]);

        barang::create([
            'id'=>'19',
            'kode_barang'=>'BRG019',
            'nama_barang'=>'Happy Tos',
            'kategori_barang'=>'Snack',
            'harga'=>'19600',
            'quantity'=>'145',

        ]);

        barang::create([
            'id'=>'20',
            'kode_barang'=>'BRG020',
            'nama_barang'=>'YOU C 100',
            'kategori_barang'=>'Minuman',
            'harga'=>'12600',
            'quantity'=>'135',

        ]);
    }
}
