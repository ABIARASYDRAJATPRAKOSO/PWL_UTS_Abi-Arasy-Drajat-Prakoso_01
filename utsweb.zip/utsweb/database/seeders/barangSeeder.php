<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\barang;

class barangSeeder extends Seeder
{
    /**
     * Run the database seeds.
     * 
     * @return void
     */
    public function run(): void
    {
        barang::create([
            'id'=>'1',
            'kode_barang'=>'BRG001',
            'nama_barang'=>'Indomie',
            'kategori_barang'=>'Makanan',
            'harga'=>'3000',
            'quantity'=>'100',

        ]);
    }
}
