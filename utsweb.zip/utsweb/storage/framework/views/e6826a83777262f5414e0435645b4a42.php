
<?php $__env->startSection('content'); ?>
    <br/>
    <br/><br/>
    <form method="GET" action="<?php echo e(url('Barang')); ?>">
        <input type="text" name="keyword" value="<?php echo e($keyword); ?>"/>
        <button type="submit">Search</button>
        <a class="btn btn-info" href="<?php echo e(url('Barang/create')); ?>">Add</a>
    </form>
    <br/><br/>
    <table class="table-bordered table">
        <tr>
            <th>id</th>
            <th>kode_barang</th>
            <th>nama_barang</th>
            <th>kategori_barang</th>
            <th>harga</th>
            <th>quantity</th>
            <th class="text-center" colspan="2">Customize<t/h>
        </tr>
        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($value->id); ?></td>
                <td><?php echo e($value->kode_barang); ?></td>
                <td><?php echo e($value->nama_barang); ?></td>
                <td><?php echo e($value->kategori_barang); ?></td>
                <td><?php echo e($value->harga); ?></td>
                <td><?php echo e($value->quantity); ?></td>
                <td><a class="btn btn-info" href="<?php echo e(url('Barang/'.$value->id. '/edit')); ?>">
                    UPDATE</a></td>
                <td>
                    <form action="<?php echo e(url('Barang/'.$value->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="_method" value="DELETE">
                        <button class="btn-danger" type="submit">DELETE</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\Web Lanjutan\utsweb\resources\views/indexGoods.blade.php ENDPATH**/ ?>