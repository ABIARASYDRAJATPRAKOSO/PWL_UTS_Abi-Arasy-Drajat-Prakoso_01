
<?php $__env->startSection('content'); ?>
    <br/>
    <form method = "POST" action= "<?php echo e(url('Barang/'.$model->id)); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_method" value="PATCH">
        kode_barang : <input type="text" name="kode_barang" value="<?php echo e($model->kode_barang); ?>"><br/>
        nama_barang : <input type="text" name="nama_barang" value="<?php echo e($model->nama_barang); ?>"><br/>
        kategori_barang : <input type="text" name="kategori_barang" value="<?php echo e($model->kategori_barang); ?>"><br/>
        harga : <input type="text" name="harga" value="<?php echo e($model->harga); ?>"><br/>
        quantity : <input type="text" name="quantity" value="<?php echo e($model->quantity); ?>"><br/>

        <button type="submit">SAVE</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\Web Lanjutan\utsweb\resources\views/editGoods.blade.php ENDPATH**/ ?>