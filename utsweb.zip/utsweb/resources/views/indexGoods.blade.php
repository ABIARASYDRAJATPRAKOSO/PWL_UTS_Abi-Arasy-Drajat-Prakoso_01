@extends('main')
@section('content')
    <br/>
    <br/><br/>
    <form method="GET" action="{{ url('Barang') }}">
        <input type="text" name="keyword" value="{{ $keyword }}"/>
        <button type="submit">Search</button>
        <a class="btn btn-info" href="{{ url('Barang/create') }}">Add</a>
    </form>
    <br/><br/>
    <table class="table-bordered table">
        <tr>
            <th>id</th>
            <th>kode_barang</th>
            <th>nama_barang</th>
            <th>kategori_barang</th>
            <th>harga</th>
            <th>quantity</th>
            <th class="text-center" colspan="2">Customize<t/h>
        </tr>
        @foreach($datas as $key=>$value)
            <tr>
                <td>{{ $value->id }}</td>
                <td>{{ $value->kode_barang }}</td>
                <td>{{ $value->nama_barang }}</td>
                <td>{{ $value->kategori_barang }}</td>
                <td>{{ $value->harga }}</td>
                <td>{{ $value->quantity }}</td>
                <td><a class="btn btn-info" href="{{ url('Barang/'.$value->id. '/edit') }}">
                    UPDATE</a></td>
                <td>
                    <form action="{{ url('Barang/'.$value->id) }}" method="POST">
                        @csrf
                        <input type="hidden" name="_method" value="DELETE">
                        <button class="btn-danger" type="submit">DELETE</button>
                    </form>
                </td>
            </tr>
        @endforeach
    </table>
@endsection