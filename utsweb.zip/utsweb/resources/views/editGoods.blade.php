@extends('main')
@section('content')
    <br/>
    <form method = "POST" action= "{{ url('Barang/'.$model->id) }}">
        @csrf
        <input type="hidden" name="_method" value="PATCH">
        kode_barang : <input type="text" name="kode_barang" value="{{ $model->kode_barang }}"><br/>
        nama_barang : <input type="text" name="nama_barang" value="{{ $model->nama_barang }}"><br/>
        kategori_barang : <input type="text" name="kategori_barang" value="{{ $model->kategori_barang }}"><br/>
        harga : <input type="text" name="harga" value="{{ $model->harga }}"><br/>
        quantity : <input type="text" name="quantity" value="{{ $model->quantity }}"><br/>

        <button type="submit">SAVE</button>
    </form>
@endsection