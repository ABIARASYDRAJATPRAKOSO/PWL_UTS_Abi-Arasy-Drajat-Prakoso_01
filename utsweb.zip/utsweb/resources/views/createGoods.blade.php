@extends('main')
@section('content')
    <br/>
    <form method = "POST" action= "{{ url('Barang') }}">
        @csrf
        id: <input type="text" name="id"><br/>
        kode_barang : <input type="text" name="kode_barang"><br/>
        nama_barang : <input type="text" name="nama_barang"><br/>
        kategori_barang : <input type="text" name="kategori_barang"><br/>
        harga : <input type="text" name="harga"><br/>
        quantity : <input type="text" name="quantity"><br/>

        <button type="submit">SAVE</button>
    </form>
@endsection